PennController.ResetPrefix()
//PreloadZip("https://github.com/avray327/child-ing-study/blob/main/sample_content.zip?raw=true")

Sequence( "intro", "tone", "Instructions", "init", randomize("priming-pictures"), "async","bye",SendResults() );
//Sequence( "intro",randomize("priming-pictures"), "bye",SendResults() );
CheckPreloaded();

InitiateRecorder("local").label("init")

UploadRecordings("async","noblock")

newTrial( "intro" ,
     newText("<p style=font-size:18px;>Welcome to our study!</p>" +
			"<p style=font-size:18px;>Please copy your Prolific ID below then press Enter to go full screen and begin!:</p>")
		.center()
        .print()
    ,
    newTextInput("inputID")
        .center()
        .print()
		.wait()
    ,
    newVar("ID")
        .global()
        .set(getTextInput("inputID"))
    //,
	//fullscreen()
).setOption("hideProgressBar",false)
.log("ID", getVar("ID")
)
PennController("tone",					
newText("Click the button to play the tone. Please adjust your headphones to ensure you can hear the tone clearly. Press continue when you are ready.")
	.settings.center()
	.print()
	,
	newButton("Play Sound")
  		.settings.center()
  		.print()
		.wait()
	,
	newAudio("tone", "BOTW_Fanfare_SmallItem.wav")
		.play()
		.wait()
	,
	newButton("Continue")
		.settings.center()
		.print()
		.wait()
	,
	getAudio("tone")
   		.stop()
)

newTrial("Instructions",
    newText("<p style=font-size:32px;>Instructions</p>") 		
        .settings.center()
        .print()
    ,
    newText("<p style=font-size:16px;>For this experiment, we are going to play a game.</p>")
		.settings.center()
        .print()
    ,
    newText("<p style=font-size:18px;>You will see two pictures and then hear a word. You should then click on the picture that matches the word you heard. Then hit “Next.”</p>")
		.settings.center()
        .print()
    ,
    newText("<p style=font-size:18px;>It is important that you do this both as quickly and accurately as possible. Click the “Next” button as soon as you have made your choice.</p>")
		.settings.center()
        .print()
    ,
     newTimer("wait", 10000)
            .start()
            .wait()
        ,
    newButton("NextInstr", "Start Experiment")
    .center()
			.print()
			.wait()

)


Template( "ing_test_lrs.csv" ,
    // Row will iteratively point to every row in myTable.csv
    row => newTrial( "priming-pictures" ,
    newMediaRecorder("recorder", "video").record()  
    ,
        newImage("image_1", row.right_pic_p)
            .size(row.x1,row.y1)
        ,
        newImage("image_2", row.left_pic_p)
            .size(row.x2,row.y2)
        ,
        newImage("image_3", row.right_pic_t)
            .size(row.x3,row.y3)
        ,		
        newImage("image_4", row.left_pic_t)
            .size(row.x4,row.y4)
        ,
        newAudio("audio_1", row.prime_sound)
        ,
        newAudio("audio_2", row.target_sound)
        ,		
        newTimer("wait1",Math.random()*500+500)    
		    .start()
            .wait()
        ,
        newCanvas("picture-canvas", 1100, 600)
            .center()
            .add( "right at 10%", "center at 50%" , getImage("image_1") )
            .add( "left at 90%", "center at 50%", getImage("image_2") )
            .print()
        ,
       newTimer("wait2", 200)
            .start()
            .wait()
        ,
        getAudio("audio_1")
            .play()
            .wait()
        ,
        newSelector("image1_image2")
			.add(getImage("image_1"), getImage("image_2"))
			.frame("solid 3px red")
			//.shuffle()
			.wait()
			.log()
        ,
		getCanvas("picture-canvas")
            .center()
            .add("center at 50%","center at 50%", newButton("Next", "<p>Next</p>"))
			.print()
		,
		getButton("Next")
			.wait()
		,
		clear()
		,
		newTimer("wait3",Math.random()*500+500)    
		    .start()
            .wait()
        ,
		newCanvas("picture-canvas-2", 1100, 600)
            .center()
            .add( "right at 10%", "center at 50%" , getImage("image_3") )
            .add( "left at 90%", "center at 50%" , getImage("image_4") )
            .print()
        ,
        newTimer("wait4", 200)
            .start()
            .wait()
        ,
        getAudio("audio_2")
            .play()
            .wait()
        ,
        newMouseTracker("mouse-2")
        .log()
        ,
	    newSelector("image3_image4")
			.add(getImage("image_3"), getImage("image_4"))
			.frame("solid 3px red")
			//.shuffle()
			.wait() 
			.log()
		,
		getMouseTracker("mouse-2")
        .stop()
		,
		getCanvas("picture-canvas-2")
            .center()
            .add("center at 50%","center at 50%", newButton("Next1", "<p>Next</p>"))
			.print()
		,
		getButton("Next1")
			.wait()
		,
		getMediaRecorder("recorder").stop()
		
    ));
    
newTrial("bye",
     newImage("debrief", "debrief.png")
        .size(1054,511)
    ,
    newCanvas("InstrCanv", 1054, 511)
            .center()
            .add("center at 50%", "top at -20%", getImage("debrief") )
            .print()
        ,
        newButton("NextInstr", "Finish")
         .print()
         .wait()
    )